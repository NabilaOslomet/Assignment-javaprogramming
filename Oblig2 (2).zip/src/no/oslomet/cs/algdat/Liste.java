package no.oslomet.cs.algdat;

import java.util.Iterator;

public interface Liste<T> extends Beholder<T> {
    public boolean leggInn(T verdi);           // Nytt element bakerst // New element at the back

    public void leggInn(int indeks, T verdi);  // Nytt element på plass indeks  
 // New item in place index

    public boolean inneholder(T verdi);        // Er verdi i listen? // Is there value in the list?

    public T hent(int indeks);                 // Hent element på plass indeks // Get item in place index

    public int indeksTil(T verdi);             // Hvor ligger verdi? 
 // Where is value?

    public T oppdater(int indeks, T verdi);    // Oppdater på plass indeks 
 // Update in place index

    public boolean fjern(T verdi);             // Fjern objektet verdi // Remove the object value

    public T fjern(int indeks);                // Fjern elementet på plass indeks // Remove the item in place index

    public int antall();                       // Antallet i listen // The number in the list

    public boolean tom();                      // Er listen tom?  
 // Is the list empty?

    public void nullstill();                   // Listen nullstilles (og tømmes) 
 // The list is reset (and emptied)

    public Iterator<T> iterator();             // En iterator

    public default String melding(int indeks)  // Unntaksmelding
    {
        return "Indeks: " + indeks + ", Antall: " + antall();
    }

    public default void indeksKontroll(int indeks, boolean leggInn) {
        if (indeks < 0 ? true : (leggInn ? indeks > antall() : indeks >= antall())) {
            throw new IndexOutOfBoundsException(melding(indeks));
        }
    }
}  // Liste