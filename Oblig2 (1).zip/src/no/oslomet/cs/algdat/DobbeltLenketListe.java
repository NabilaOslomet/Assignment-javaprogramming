package no.oslomet.cs.algdat;


////////////////// class DobbeltLenketListe //////////////////////////////


import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.NoSuchElementException;
import java.util.StringJoiner;

import java.util.Iterator;
import java.util.Objects;
import java.util.function.Predicate;













public class DobbeltLenketListe<T> implements Liste<T> {

    /**
     * Node class
     * @param <T>
     */
    private static final class Node<T> {
        private T verdi;                   // nodens verdi //value of node
        private Node<T> forrige, neste;    // pekere // pointers previous next

        private Node(T verdi, Node<T> forrige, Node<T> neste) {
            this.verdi = verdi;
            this.forrige = forrige;
            this.neste = neste;
        }

        private Node(T verdi) {
            this(verdi, null, null);
        }
    }

    // instansvariabler
    private Node<T> hode;          // peker til den første i listen // points to the first in the list
    private Node<T> hale;          // peker til den siste i listen // points to the last in the list
    private int antall;            // antall noder i listen // number of nodes in the list
    private int endringer;         // antall endringer i listen // number of changes in the list

    public DobbeltLenketListe() {
        //throw new UnsupportedOperationException();
    }

    public DobbeltLenketListe(T[] a) {
    	if(a==null) {
    		//antall=0;
    		throw new NullPointerException();
    		
    	}
    	if(a.length==0) {
    		hode=null;
    		hale=null;
    		antall=0;
    	}
    	
    	if(a.length>=1) {
    		int first=0;
    		for(int i=0;i<a.length;i++) {
    			if(a[i]!=null) {
    				first=i;
    				//System.out.println(first);
    				break;
    				
    			}
    		}
    			if(hode==null && a[first]!=null ) {
    				//System.out.println(first);
    				Node<T> node=new Node<T>(a[first]);
    				hode=node;
    				hale=node;
    				
    				hode.forrige=null;
    				//hode.neste=null;
    				//hale.forrige=null;
    				hale.neste=null;
    				antall++;
    			}
    			for(int i=first+1;i<a.length;i++) {
    				
    			if( a[i]!=null ) {
    				
    				Node<T> node=new Node<T>(a[i]);
    				
    				hale.neste=node;
    				node.forrige=hale;
    				//node=hale.neste;
    				hale=node;
    				hale.neste=null;
    				antall++;
    			}
    			
    		}}
    	//System.out.println(hale.forrige.verdi);
    	//System.out.println(hode.verdi);
        //throw new UnsupportedOperationException();
    }

    public Liste<T> subliste(int fra, int til){
    	Liste<T> List=new DobbeltLenketListe<T>();
    	Node<T> node=new Node<T>(null);
    	Node<T> node1=new Node<T>(null);
    	Node<T> node2=new Node<T>(null);
    	int counter=0;
    	if(fra<0 || fra>antall) {
    		throw new IndexOutOfBoundsException();
    	}
    	if(til<0 || til>antall) {
    		throw new IndexOutOfBoundsException();
    	}
    	if(fra>til) {
    		throw new IllegalArgumentException();
    	}
    	if(fra==til) {
    		return List;
    		//List.leggInn(0);
    	}
    	else {
    		
    		node1=hode;
    		int t=0;
    		while(t!=fra) {
    			node1=node1.neste;
    			t++;
    		}
    		
    		int diff=til-fra;
    		while(diff!=counter) {
    			
    			List.leggInn(node1.verdi);
    			node1=node1.neste;
    			counter++;
    			}
    			return List;
    		
    	
    		
    	}
        
    }

    @Override
    public int antall() {
    	//System.out.println(antall);
    	return antall;
        //throw new UnsupportedOperationException();
    }

    @Override
    public boolean tom() {
    	if (antall==0) {
    		return true;
    	}
    	else
    		return false;
        //throw new UnsupportedOperationException();
    }

    @Override
    public boolean leggInn(T verdi) {
        //throw new UnsupportedOperationException();
    	if(verdi==null) {
    		throw new NullPointerException();
    	}
    	Node<T> node=new Node<T>(verdi);
    	if(hode==null && hale==null) {
    		hode=node;
    		hale=node;
    		antall++;
    	}
    	//hode=node;
    	//hode=node;
		//hale=node;
    	else {
		//hode.forrige=null;
		hale.neste=node;
		node.forrige=hale;
		//node=hale.neste;
		hale=node;
		hale.neste=null;
		antall++;}
        //throw new UnsupportedOperationException();
    	//System.out.println(antall);
		return true;
    }

    @Override
    public void leggInn(int indeks, T verdi) {
    	Node<T> node=new Node<T>(null);
    	Node<T> node1=new Node<T>(null);
    	Node<T> node2=new Node<T>(null);
    	if(indeks<0 || indeks>antall) {
    		throw new IndexOutOfBoundsException();
    	}
    	if(verdi==null) {
    		throw new NullPointerException();
    	}
    	if(hode==null && indeks>0) {
    	throw new IndexOutOfBoundsException();	
    	}
    	if(indeks==0) {
    		//System.out.println("Hi");
    		//hode.forrige=node;
    		//node.neste=hode;
    		node.neste=hode;
    		hode=node;
    		//hale=node;
    		hode.verdi=verdi;
    		hode.forrige=null;
    		antall++;
    		endringer++;
    	}
    	if(indeks==antall) {
    		node.forrige=hale;
    		hale=node;;
    	hale.verdi=verdi;
    		hale.neste=null;
    		antall++;
    		endringer++;
    	}
        //throw new UnsupportedOperationException();
    }

    @Override
    public boolean inneholder(T verdi) {
    	int check=indeksTil(verdi);
    	if(check==-1) {
    		return false;
    	}
    	else {
    		return true;
    	}
        //throw new UnsupportedOperationException();
    }

    @Override
    public T hent(int indeks) {
    	Node<T> node=new Node<T>(null);
    	node=finnNode(indeks);
    	//System.out.println(node.verdi);
    	 return node.verdi;
    }

    @Override
    public int indeksTil(T verdi) {
    	 Node<T> node=new Node<T>(null);
		  int i=0;
		   node=hode;
		   if(hode==null|| verdi==null) {
			   return -1;
		   }
		   
				if(hode.verdi.equals(verdi)) {
					return 0;
				}
				
				 do {
					 if(node.verdi.equals(verdi)) {
						 break;
					 }
					 i++;
					 node=node.neste;
				 }while(i!=antall);
				 if(i==antall) {
					 return -1;
				 }
				 return i;
			 }

    @Override
    public T oppdater(int indeks, T nyverdi) {
    	Node<T> node=new Node<T>(null);
    	Node<T> node1=new Node<T>(null);
    	int current=0;
    	if(nyverdi==null) {
    		throw new NullPointerException();
    	}
    	if(indeks < 0 || indeks > antall && hode==null) { 
            throw new IndexOutOfBoundsException(); 
    			  } 
    	if(indeks==antall) {
    		throw new IndexOutOfBoundsException();
    	}
    	
    	if(indeks==0) {
    		node1.verdi=hode.verdi;
    		hode.verdi=nyverdi;
    		endringer++;
    		return node1.verdi;
    	}
    	if(indeks==antall-1) {
    		node1.verdi=hale.verdi;
    		hale.verdi=nyverdi;
    		endringer++;
    		return node1.verdi;
    	}
    	else {
    		node=hode;
    	 while(current!=indeks){
	    		
			
	    		//sb.append(" ,");
	    		node=node.neste;
	    		current++;
	    		
	 }
    	 node1.verdi=node.verdi;
    	 node.verdi=nyverdi;
    	 endringer++;
    	 return node1.verdi;
       
    }}

    @Override
    public boolean fjern(T verdi) {
        throw new UnsupportedOperationException();
    }

    @Override
    public T fjern(int indeks) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void nullstill() {
        throw new UnsupportedOperationException();
    }

    @Override
    public String toString() {
    	 StringBuilder sb=new StringBuilder();
     	sb.append("[");
     	Node<T> node=new Node<T>(null);
     	node=hode;
     	while(node!=null){
     		sb.append(node.verdi);sb.append(",");sb.append(" ");
     		//sb.append(" ,");
     		node=node.neste;
     	}
     	//sb=sb.substring(0,4);
     	
     	sb.append("]");
     	if(sb.length()==2) {
     		//System.out.println(antall);
     		return sb.toString();
     	}
     	else {
     		StringBuilder st=sb.deleteCharAt(sb.length()-2);
    		st.deleteCharAt(st.length()-2);
    		//sb.deleteCharAt(sb.length()-3);
    		
    		return st.toString();
     	}
     	
    }

    public String omvendtString() {
    	StringBuilder sb=new StringBuilder();
    	sb.append("[");
    	    	
    	    	Node<T> node=new Node<T>(null);
    	    	node=hale;
    	    	while(node!=null){
    	    		sb.append(node.verdi);sb.append(",");sb.append(" ");
    	    		//System.out.println(node.verdi);
    	    		node=node.forrige;
    	    	}
    	        //throw new UnsupportedOperationException();

    	    	sb.append("]");
    	    	if(sb.length()==2) {
    	    		//System.out.println(antall);
    	    		return sb.toString();
    	    	}
    	    	else {
    	    		StringBuilder st=sb.deleteCharAt(sb.length()-2);
    	    		st.deleteCharAt(st.length()-2);
    	    		//sb.deleteCharAt(sb.length()-3);
    	    		
    	    		return st.toString();
    	    	}
    }
    private Node<T> finnNode(int indeks) { 
		  Node<T> node=new Node<T>(null);
		  
		  int current=0;
		  if(indeks < 0 || indeks >= antall|| hode==null) { 
        throw new IndexOutOfBoundsException(); 
			  } 
		  
			  
			 if(indeks<=antall/2 || indeks==0) {
				 node=hode;
				 
				 while(current!=indeks){
			    		
					 
			    		//sb.append(" ,");
			    		node=node.neste;
			    		current++;
			    		
			 }
				 return node;
				 }
			 if(indeks==antall-1) {
				 return hale;
			 }
			 else {
				 node=hale;
				 int len=antall;
				 while(len!=indeks){
			    		
					 
			    		//sb.append(" ,");
			    		node=node.forrige;
			    		len--;
			 }
				 
		    	
		    		return node;
		    		
		    		}
		    	 //return node;	
	  
		 // System.out.println(current);
		     
		  }
    @Override
    public Iterator<T> iterator() {
        throw new UnsupportedOperationException();
    }

    public Iterator<T> iterator(int indeks) {
        throw new UnsupportedOperationException();
    }

    private class DobbeltLenketListeIterator implements Iterator<T>
    {
        private Node<T> denne;
        private boolean fjernOK;
        private int iteratorendringer;

        private DobbeltLenketListeIterator(){
            denne = hode;     // p starter på den første i listen
            fjernOK = false;  // blir sann når next() kalles
            iteratorendringer = endringer;  // teller endringer
        }

        private DobbeltLenketListeIterator(int indeks){
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean hasNext(){
            return denne != null;
        }

        @Override
        public T next(){
            throw new UnsupportedOperationException();
        }

        @Override
        public void remove(){
            throw new UnsupportedOperationException();
        }

    } // class DobbeltLenketListeIterator

    public static <T> void sorter(Liste<T> liste, Comparator<? super T> c) {
        throw new UnsupportedOperationException();
    }

} // class DobbeltLenketListe


